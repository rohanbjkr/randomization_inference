# import pandas as pd

# def extract_regression_results(model, variables, model_name, show_tvalues=True):
#     """
#     Extracts coefficients, t-values (or SEs), and observations from a regression model.
#     """
#     results = {}
#     for var in variables:
#         results[f'{model_name}_{var}_b'] = round(model.params.get(var, ""), 3) if var in model.params else ""
        
#         # Choose to display t-values or standard errors based on show_tvalues
#         if show_tvalues:
#             results[f'{model_name}_{var}_se'] = f"({round(model.tvalues.get(var, ''), 3)})" if var in model.tvalues else ""
#         else:
#             results[f'{model_name}_{var}_se'] = f"({round(model.bse.get(var, ''), 3)})" if var in model.bse else ""
    
#     results[f'{model_name}_obs'] = int(model.nobs) if hasattr(model, 'nobs') else ""
#     return results

# def format_coef(coef):
#     """Formats coefficients, keeping missing values empty."""
#     return coef if coef != "" else ""

# def extract_model_results(model_name, variables, results_dict, show_tvalues=True):
#     """
#     Extracts coefficients and either t-values or standard errors for a given model,
#     ensuring proper alignment for the table.
#     """
#     flattened_results = []
#     for var in variables:
#         flattened_results.append(format_coef(results_dict.get(f'{model_name}_{var}_b', "")))
        
#         # Choose to display t-values or standard errors based on show_tvalues
#         flattened_results.append(results_dict.get(f'{model_name}_{var}_se', ""))
        
#     return flattened_results

# def create_regression_table(models_dict, vars_save, var_name_map, show_tvalues=True):
#     """
#     Generates a Pandas DataFrame with regression results for selected variables.
#     Allows choosing between displaying t-values or standard errors.
#     """
#     # Extract results for all models
#     all_results = {}
#     for model_name, model in models_dict.items():
#         all_results.update(extract_regression_results(model, vars_save, model_name, show_tvalues))

#     # Ensure the variable names appear twice (once for coefficients, once for SEs/t-values)
#     table_headers = sum([[var_name_map.get(var, var), ""] for var in vars_save], [])

#     # Construct data dictionary dynamically
#     data = {"": table_headers}  # First column for variable names
#     for model_name in models_dict.keys():
#         data[model_name] = extract_model_results(model_name, vars_save, all_results, show_tvalues)

#     # Convert dictionary to DataFrame
#     return pd.DataFrame(data)


import pandas as pd

def extract_regression_results(model, variables, model_name, show_tvalues=True, decimal_points=3, include_obs=True, include_r2=False):
    """
    Extracts coefficients, t-values (or SEs), observations, and R-squared from a regression model.
    """
    results = {}
    for var in variables:
        # Extract coefficients with the specified number of decimal points
        results[f'{model_name}_{var}_b'] = round(model.params.get(var, ""), decimal_points) if var in model.params else None
        
        # Choose to display t-values or standard errors based on show_tvalues
        if show_tvalues:
            results[f'{model_name}_{var}_se'] = f"({round(model.tvalues.get(var, ''), decimal_points)})" if var in model.tvalues else None
        else:
            results[f'{model_name}_{var}_se'] = f"({round(model.bse.get(var, ''), decimal_points)})" if var in model.bse else None
    
    # Add number of observations if requested
    if include_obs:
        results[f'{model_name}_obs'] = int(model.nobs) if hasattr(model, 'nobs') else None
    
    # Add R-squared if requested
    if include_r2:
        results[f'{model_name}_r2'] = round(model.rsquared, decimal_points) if hasattr(model, 'rsquared') else None
    
    return results

def format_coef(coef):
    """Formats coefficients, keeping missing values empty."""
    return coef if coef is not None else ""

def extract_model_results(model_name, variables, results_dict, show_tvalues=True, include_r2=False, include_obs=True):
    """
    Extracts coefficients and either t-values or standard errors for a given model,
    ensuring proper alignment for the table.
    """
    flattened_results = []
    for var in variables:
        flattened_results.append(format_coef(results_dict.get(f'{model_name}_{var}_b', None)))
        
        # Choose to display t-values or standard errors based on show_tvalues
        flattened_results.append(results_dict.get(f'{model_name}_{var}_se', None))

    return flattened_results

def create_regression_table(models_dict, vars, var_labels, show_tvalues=True, decimal_points=3, include_obs=True, include_r2=False):
    """
    Generates a Pandas DataFrame with regression results for selected variables.
    Allows choosing between displaying t-values or standard errors.
    Also allows setting decimal points, including observations, and including R-squared values.
    """
    # Extract results for all models
    all_results = {}
    for model_name, model in models_dict.items():
        all_results.update(extract_regression_results(model, vars, model_name, show_tvalues, decimal_points, include_obs, include_r2))

    # Ensure the variable names appear twice (once for coefficients, once for SEs/t-values)
    table_headers = sum([[var_labels.get(var, var), ""] for var in vars], [])

    # Construct data dictionary dynamically
    data = {"": table_headers}  # First column for variable names
    for model_name in models_dict.keys():
        data[model_name] = extract_model_results(model_name, vars, all_results, show_tvalues, include_r2, include_obs)

    # Add Observations and R-squared as the last row(s) if included
    if include_obs or include_r2:
        # Create a list to hold the bottom row(s)
        bottom_rows = []

        # Add Observations row if requested
        if include_obs:
            obs_row = ["Observations"] + [all_results.get(f'{model_name}_obs', "") for model_name in models_dict.keys()]
            bottom_rows.append(obs_row)

        # Add R-squared row if requested
        if include_r2:
            r2_row = ["R-squared"] + [all_results.get(f'{model_name}_r2', "") for model_name in models_dict.keys()]
            bottom_rows.append(r2_row)

        # Append the bottom row(s) to the data dictionary
        for row in bottom_rows:
            data[""].append(row[0])  # Add the label (e.g., "Observations" or "R-squared")
            for model_name in models_dict.keys():
                data[model_name].append(row[list(models_dict.keys()).index(model_name) + 1])

    # Convert dictionary to DataFrame
    df = pd.DataFrame(data)

    return df







