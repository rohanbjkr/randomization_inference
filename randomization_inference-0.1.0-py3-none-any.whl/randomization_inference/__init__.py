"""
Randomization Inference Package

This package provides functions for performing randomization inference.
"""
